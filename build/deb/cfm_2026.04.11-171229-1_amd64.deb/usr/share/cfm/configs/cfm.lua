-- /usr/local/openresty/nginx/lua/cfm.lua
--
-- CFM OpenResty in-path enforcement
-- Based on the proven Mars version with minimal additions:
--   [R1] Traffic rules: ua/country passed to bridge, rule_action/throttle handled
--   [R2] pcall fail-open: any uncaught Lua error defaults to serving via Apache
--   [R3] cfm_rules throttle module support (optional)
--
-- Design principles:
--   - Per-request bridge RPC with 9-second shared-dict cache for allows
--   - No timer callbacks, no event queues, no snapshot polling
--   - Socket calls are best-effort with short timeouts and fail-open
--   - Cache means 95%+ of requests never touch the socket

local cjson = require "cjson.safe"


-- ─────────────────────────────────────────────────────────────────────────────
-- CONFIG
-- ─────────────────────────────────────────────────────────────────────────────
local CFG = {
  sock_path = "/var/run/cfm/cfm_nginx.sock",

  token        = "cfm",
  token_header = "X-CFM-Token",

  decision_timeout_ms   = 80,
  decision_cache_ttl_ms = 12000,
  waf_excl_cache_ttl_ms = tonumber(os.getenv("CFM_WAF_EXCL_CACHE_TTL_MS") or "5000"),
  waf_excl_meta_ttl_sec = tonumber(os.getenv("CFM_WAF_EXCL_META_TTL_SEC") or "15"),
  waf_excl_refresh_sec  = tonumber(os.getenv("CFM_WAF_EXCL_REFRESH_SEC") or "10"),

  block_code = 403,
  fail_open  = true,

  debug         = (os.getenv("CFM_DEBUG") == "1"),
  debug_headers = (os.getenv("CFM_DEBUG_HEADERS") == "1"),
  log_allows    = (os.getenv("CFM_LOG_ALLOWS") == "1"),

  ok_ttl_sec         = tonumber(os.getenv("CFM_OK_TTL_SEC")         or "1800"),
  ok_touch_every_sec = tonumber(os.getenv("CFM_OK_TOUCH_EVERY_SEC") or "120"),

  keepalive_idle_ms = tonumber(os.getenv("CFM_BRIDGE_KA_IDLE_MS") or "15000"),
  keepalive_pool    = tonumber(os.getenv("CFM_BRIDGE_KA_POOL")    or "128"),

  waf_body_max_len = tonumber(os.getenv("CFM_WAF_BODY_MAX_LEN") or "8192"),

  post_resume_enable  = (os.getenv("CFM_POST_RESUME_ENABLE") or "1") == "1",
  post_resume_max_len = tonumber(os.getenv("CFM_POST_RESUME_MAX_LEN") or "65536"),
  post_resume_ttl_sec = tonumber(os.getenv("CFM_POST_RESUME_TTL_SEC") or "90"),
}

local clamav_ok, clamav = pcall(require, "cfm_clamav")
if clamav_ok then clamav.init({ token = CFG.token, sock_path = CFG.sock_path }) end

-- [R3] cfm_rules is optional (throttle enforcement)
local rules_ok, rules = pcall(require, "cfm_rules")
if rules_ok and rules and rules.init then rules.init(CFG) end

local SH = ngx.shared.cfm_decisions

-- ─────────────────────────────────────────────────────────────────────────────
-- UTILS
-- ─────────────────────────────────────────────────────────────────────────────

local function log_route(level, msg) ngx.log(level or ngx.WARN, "[cfm] ", msg) end
local function esc(s) return ngx.escape_uri(s or "") end

local function with_query_arg(u, k, v)
  u = tostring(u or "/")
  local sep = u:find("?", 1, true) and "&" or "?"
  return u .. sep .. tostring(k or "") .. "=" .. esc(v or "")
end

local function append_set_cookie(v)
  local h = ngx.header["Set-Cookie"]
  if not h then ngx.header["Set-Cookie"] = v; return end
  if type(h) == "table" then table.insert(h, v); ngx.header["Set-Cookie"] = h; return end
  ngx.header["Set-Cookie"] = { h, v }
end

local function real_ip()
  local rip = ngx.var.remote_addr
  if rip and rip ~= "" then return rip end
  local cf = ngx.var.http_cf_connecting_ip
  if cf and cf ~= "" then return cf end
  return "-"
end

local function lower(s) if not s then return "" end; return string.lower(s) end

local function has(s, pat)
  if not s or s == "" then return false end
  return string.find(s, pat, 1, true) ~= nil
end

-- ─────────────────────────────────────────────────────────────────────────────
-- WAF BODY INSPECTION
-- ─────────────────────────────────────────────────────────────────────────────

local function waf_should_read_body(uri, method)
  uri    = lower(uri    or "")
  method = lower(method or "")
  if method ~= "post" then return false end
  if has(uri, "/xmlrpc.php")      then return true end
  if has(uri, "/wp-login.php")    then return true end
  if has(uri, "/wp-signup.php")   then return true end
  if has(uri, "/wp-activate.php") then return true end
  if has(uri, "/admin-ajax.php")  then return true end
  if has(uri, "/ajax")            then return true end
  if has(uri, "/api/")            then return true end
  if has(uri, "/graphql")         then return true end
  if has(uri, "/rest/")           then return true end
  if has(uri, "/wp-json/")        then return true end
  if has(uri, "/wp-admin/")       then return true end
  if has(uri, "/wp-content/")     then return true end
  if has(uri, "/wp-includes/")    then return true end
  if has(uri, "/wc-api/")         then return true end
  if has(uri, "wc-ajax=")         then return true end
  if has(uri, "/administrator/")  then return true end
  if has(uri, "/components/")     then return true end
  if has(uri, "/modules/")        then return true end
  if has(uri, "/plugins/")        then return true end
  if has(uri, "/templates/")      then return true end
  if has(uri, "/media/")          then return true end
  if has(uri, "/user/login")      then return true end
  if has(uri, "/admin")           then return true end
  if has(uri, "/login")           then return true end
  if has(uri, "/auth")            then return true end
  if has(uri, "/upload")          then return true end
  if has(uri, "/import")          then return true end
  if has(uri, "/install")         then return true end
  if has(uri, "/setup")           then return true end
  if has(uri, "/update")          then return true end
  if has(uri, "/filemanager")     then return true end
  if has(uri, "/connector")       then return true end
  if has(uri, "/shell")           then return true end
  if has(uri, "/cmd")             then return true end
  if has(uri, "/cgi-bin/")        then return true end
  if has(uri, "/_ignition/")      then return true end
  if has(uri, "timthumb.php")     then return true end
  if has(uri, "/webservice/")     then return true end
  if has(uri, "/backend/")        then return true end
  if has(uri, "/catalog/")        then return true end
  if has(uri, "/system/")         then return true end
  if has(uri, "/extension/")      then return true end
  if has(uri, "/sites/default/")  then return true end
  if uri:match("/upload[s]?/.*%.php") then return true end
  if uri:match("/files/.*%.php")      then return true end
  if uri:match("%.php[%?/].*")   then return true end
  if uri:match("%.phtml[%?/].*") then return true end
  if uri:match("%.php$")         then return true end
  if uri:match("%.phtml$")       then return true end
  return false
end

local function get_req_body_for_waf(uri, method, max_len)
  if not waf_should_read_body(uri, method) then return "" end
  if ngx.ctx.waf_body ~= nil then return ngx.ctx.waf_body end
  ngx.req.read_body()
  local data = ngx.req.get_body_data()
  if data and data ~= "" then
    local result = (#data > max_len) and string.sub(data, 1, max_len) or data
    ngx.ctx.waf_body = result; return result
  end
  local body_file = ngx.req.get_body_file()
  if body_file and body_file ~= "" then
    local f = io.open(body_file, "rb")
    if f then local chunk = f:read(max_len) or ""; f:close(); ngx.ctx.waf_body = chunk; return chunk end
  end
  ngx.ctx.waf_body = ""; return ""
end

-- ─────────────────────────────────────────────────────────────────────────────
-- POST RESUME
-- ─────────────────────────────────────────────────────────────────────────────

local function ct_allows_resume(ct)
  ct = lower(ct or "")
  if ct == "" then return false end
  if has(ct, "application/x-www-form-urlencoded") then return true end
  if has(ct, "application/json")  then return true end
  if has(ct, "text/plain")        then return true end
  return false
end

local function build_resume_token()
  return ngx.md5(table.concat({
    ngx.var.request_id or "", tostring(ngx.worker.pid()), tostring(ngx.now()),
  }, "|"))
end

local function store_post_resume(ip, host, uri, method)
  if not CFG.post_resume_enable or not SH then return nil, "disabled" end
  if lower(method or "") ~= "post" then return nil, "not_post" end
  local ctype = ngx.var.content_type or ""
  if not ct_allows_resume(ctype) then return nil, "ctype_not_allowed" end
  local clen = tonumber(ngx.var.content_length or "0") or 0
  if clen <= 0 or clen > CFG.post_resume_max_len then return nil, "size_limit" end
  ngx.req.read_body()
  local body = ngx.req.get_body_data()
  if not body or #body == 0 or #body > CFG.post_resume_max_len then return nil, "body_size" end
  local token = build_resume_token()
  SH:set("pr|" .. token, cjson.encode({
    ip = ip, host = host, uri = uri, method = "POST",
    ctype = ctype, body_b64 = ngx.encode_base64(body), ts = ngx.time(),
  }), CFG.post_resume_ttl_sec)
  return token, nil
end

local function try_apply_post_resume(ip, host)
  if not CFG.post_resume_enable or not SH then return false end
  if lower(ngx.req.get_method() or "") ~= "get" then return false end
  local args = ngx.req.get_uri_args()
  local tok = args and args["cfm_rt"]
  if type(tok) == "table" then tok = tok[1] end
  tok = tostring(tok or "")
  if tok == "" then return false end
  local raw = SH:get("pr|" .. tok); SH:delete("pr|" .. tok)
  if not raw then return false end
  local obj = cjson.decode(raw)
  if not obj then return false end
  if tostring(obj.ip or "") ~= tostring(ip or "") then return false end
  if tostring(obj.host or "") ~= tostring(host or "") then return false end
  local body = ngx.decode_base64(obj.body_b64 or "")
  if not body or #body == 0 or #body > CFG.post_resume_max_len then return false end
  ngx.req.set_method(ngx.HTTP_POST)
  ngx.req.set_header("Content-Type", obj.ctype or "application/x-www-form-urlencoded")
  ngx.req.set_body_data(body)
  local target_uri = obj.uri or "/"
  local qidx = target_uri:find("?", 1, true)
  if qidx then
    ngx.req.set_uri(target_uri:sub(1, qidx - 1), false)
    ngx.req.set_uri_args(target_uri:sub(qidx + 1))
  else
    ngx.req.set_uri(target_uri, false); ngx.req.set_uri_args(nil)
  end
  ngx.ctx.cfm_resumed_post = true
  log_route(ngx.INFO, "post_resume_applied ip=" .. tostring(ip) ..
    " host=" .. tostring(host) .. " uri=" .. tostring(target_uri))
  return true
end

-- ─────────────────────────────────────────────────────────────────────────────
-- NETWORK LAYER
-- ─────────────────────────────────────────────────────────────────────────────

local function read_chunked(sock)
  local out = {}
  while true do
    local line, err = sock:receive("*l")
    if not line then return nil, "chunked size line: " .. (err or "?") end
    local hex = line:match("^%s*([0-9a-fA-F]+)")
    if not hex then return nil, "bad chunk size line: " .. tostring(line) end
    local n = tonumber(hex, 16)
    if not n then return nil, "bad chunk size hex: " .. tostring(hex) end
    if n == 0 then
      while true do local tl = sock:receive("*l"); if not tl or tl == "" then break end end
      break
    end
    local data, derr = sock:receive(n)
    if not data then return nil, "chunk read: " .. (derr or "?") end
    table.insert(out, data); sock:receive(2)
  end
  return table.concat(out), nil
end

local function http_unix(method, path, body)
  local s, err = ngx.socket.tcp()
  if not s then return nil, "socket.tcp: " .. (err or "unknown") end
  s:settimeouts(CFG.decision_timeout_ms, CFG.decision_timeout_ms, CFG.decision_timeout_ms)
  local ok, cerr = s:connect("unix:" .. CFG.sock_path)
  if not ok then s:close(); return nil, "connect: " .. (cerr or "unknown") end
  body = body or ""
  local req = method .. " " .. path .. " HTTP/1.1\r\nHost: localhost\r\nConnection: keep-alive\r\n"
  if CFG.token and CFG.token ~= "" then
    req = req .. CFG.token_header .. ": " .. CFG.token .. "\r\n"
  end
  if method == "POST" then
    req = req .. "Content-Type: application/json\r\nContent-Length: " .. tostring(#body) .. "\r\n"
  end
  req = req .. "\r\n" .. body
  local _, werr = s:send(req)
  if werr then s:close(); return nil, "send: " .. (werr or "unknown") end
  local status_line, rerr = s:receive("*l")
  if not status_line then s:close(); return nil, "recv status: " .. (rerr or "unknown") end
  local code = tonumber(status_line:match("%s(%d%d%d)%s"))
  if not code then s:close(); return nil, "bad status line: " .. status_line end
  local content_length, is_chunked
  while true do
    local line, _ = s:receive("*l")
    if not line or line == "" then break end
    local k, v = line:match("^([^:]+):%s*(.*)$")
    if k and v then
      local kl = k:lower()
      if kl == "content-length" then content_length = tonumber(v)
      elseif kl == "transfer-encoding" and v:lower():find("chunked", 1, true) then is_chunked = true end
    end
  end
  local resp = ""
  if method == "HEAD" or code == 204 or code == 304 then resp = ""
  elseif content_length and content_length > 0 then resp = s:receive(content_length)
  elseif is_chunked then
    local b, berr = read_chunked(s); if not b then s:close(); return nil, berr end; resp = b
  else resp = s:receive("*a") or "" end
  local ok_ka = s:setkeepalive(CFG.keepalive_idle_ms, CFG.keepalive_pool)
  if not ok_ka then s:close() end
  if code ~= 200 then return nil, "http " .. tostring(code) .. " body=" .. tostring(resp) end
  return resp, nil
end

local function http_get_unix(path_qs)  return http_unix("GET",  path_qs, nil) end
local function http_post_unix(path, b) return http_unix("POST", path,    b)   end

-- ─────────────────────────────────────────────────────────────────────────────
-- HELPERS
-- ─────────────────────────────────────────────────────────────────────────────

local function observe_waf(ip, host, uri, method, status, reason)
  if not ip or ip == "" then return end
  http_post_unix("/nginx/observe", cjson.encode({
    ip = ip, host = host or "", uri = uri or "/",
    method = method or "", status = status or 403, reason = reason or "",
  }))
end

local function touch_ok(ip)
  if not SH then return end
  local k = "ok_touch|" .. (ip or "-")
  local now = ngx.now()
  local last = SH:get(k)
  if last and (now - last) < CFG.ok_touch_every_sec then return end
  SH:set(k, now, CFG.ok_touch_every_sec)
  http_post_unix("/nginx/ok/touch", cjson.encode({ ip = ip, ttl_sec = CFG.ok_ttl_sec }))
end

local function refresh_ok_cookie(cookie_val)
  if not cookie_val or cookie_val == "" then return end
  local attrs = "Path=/; Max-Age=" .. tostring(CFG.ok_ttl_sec) .. "; HttpOnly; SameSite=Lax"
  if ngx.var.scheme == "https" then attrs = attrs .. "; Secure" end
  append_set_cookie("cfm_ok=" .. cookie_val .. "; " .. attrs)
end

local function fail_decision(errmsg)
  if CFG.fail_open then
    return { ip_action = "allow", vhost_action = "allow", err = errmsg }
  else
    return { ip_action = "block", vhost_action = "block", err = errmsg }
  end
end

-- [R1] Pass ua + country so Go evaluates traffic rules. Cache clean allows only.
local function get_decision(ip, host, uri, method, scheme, ua, country)
  local uri_part = (uri or "-"):sub(1, 64)
  local key = "d|" .. ip .. "|" .. host .. "|" .. method .. "|" .. scheme .. "|" .. uri_part

  if SH then
    local cached = SH:get(key)
    if cached then
      local obj = cjson.decode(cached)
      if obj then obj._cache = true; return obj end
    end
  end

  local path = "/nginx/decision?ip=" .. esc(ip) ..
               "&host="    .. esc(host)    ..
               "&uri="     .. esc(uri)     ..
               "&method="  .. esc(method)  ..
               "&scheme="  .. esc(scheme)  ..
               "&ua="      .. esc(ua or "")      ..
               "&country=" .. esc(country or "")

  local body, err = http_get_unix(path)
  if not body then return fail_decision(err) end
  local obj = cjson.decode(body)
  if not obj then return fail_decision("decode_failed") end

  -- Only cache clean allows (no rule action = no challenge/block/throttle pending)
  if SH and obj.ip_action == "allow" and obj.vhost_action == "allow"
     and not obj.rule_action then
    SH:set(key, body, CFG.decision_cache_ttl_ms / 1000)
  end
  return obj
end

-- WAF excludes snapshot
local function refresh_waf_excludes_if_needed()
  if not SH then return end
  local now = ngx.now()
  local last = tonumber(SH:get("wxsnap_ts") or "0") or 0
  if (now - last) < CFG.waf_excl_refresh_sec then return end
  if not SH:add("wxsnap_lock", "1", 1) then return end
  local body, _ = http_get_unix("/nginx/waf/excludes")
  if not body then
    SH:set("wxsnap_ts", now, math.max(1, CFG.waf_excl_refresh_sec))
    SH:delete("wxsnap_lock"); return
  end
  local entries = (cjson.decode(body) or {}).entries or {}
  local hosts, paths = {}, {}
  for _, e in ipairs(entries) do
    local t = lower(e.type or ""); local v = lower(tostring(e.value or ""))
    if v ~= "" then
      if t == "host" then hosts[#hosts+1] = v elseif t == "path" then paths[#paths+1] = v end
    end
  end
  SH:set("wxhosts", cjson.encode(hosts), math.max(1, CFG.waf_excl_meta_ttl_sec))
  SH:set("wxpaths", cjson.encode(paths), math.max(1, CFG.waf_excl_meta_ttl_sec))
  SH:set("wxsnap_ts", now, math.max(1, CFG.waf_excl_refresh_sec))
  SH:delete("wxsnap_lock")
end

local wx_local_ts = 0
local wx_local_hosts = {}
local wx_local_paths = {}

local function glob_to_lua_pattern(glob)
  local p = tostring(glob or "")
  p = p:gsub("([%^%$%(%)%%%.%[%]%+%-%*%?])", "%%%1")
  p = p:gsub("%%%*", ".*"); p = p:gsub("%%%?", ".")
  return "^" .. p .. "$"
end

local function matches_rule(value, rule)
  value = lower(tostring(value or "")); rule = lower(tostring(rule or ""))
  if value == "" or rule == "" then return false end
  if rule:find("*", 1, true) or rule:find("?", 1, true) then
    local ok, res = pcall(function() return value:match(glob_to_lua_pattern(rule)) ~= nil end)
    return ok and res or false
  end
  return value:find(rule, 1, true) ~= nil
end

local function load_waf_excludes_local_cache()
  if not SH then wx_local_ts = 0; wx_local_hosts = {}; wx_local_paths = {}; return end
  local ts = tonumber(SH:get("wxsnap_ts") or "0") or 0
  if ts == wx_local_ts then return end
  wx_local_ts = ts
  wx_local_hosts = cjson.decode(SH:get("wxhosts") or "[]") or {}
  wx_local_paths = cjson.decode(SH:get("wxpaths") or "[]") or {}
end

local function waf_is_excluded(host, uri)
  refresh_waf_excludes_if_needed(); load_waf_excludes_local_cache()
  host = lower(host or ""); uri = lower(tostring(uri or "/"))
  for _, r in ipairs(wx_local_hosts) do if matches_rule(host, r) then return true end end
  for _, r in ipairs(wx_local_paths) do if matches_rule(uri, r) then return true end end
  return false
end

-- ─────────────────────────────────────────────────────────────────────────────
-- GEO LOOKUP (lazy, per-worker singleton)
-- ─────────────────────────────────────────────────────────────────────────────
local mmdb_ok, mmdb = pcall(require, "resty.maxminddb")
-- Guard: module loaded but API doesn't match what we expect
if mmdb_ok and (type(mmdb) ~= "table" or type(mmdb.new) ~= "function") then
    ngx.log(ngx.WARN, "[cfm] lua-resty-maxminddb loaded but missing .new — geo disabled")
    mmdb_ok = false
end

local _geo_db     = nil
local _geo_db_err = false

local GEO_DB_PATH = os.getenv("CFM_GEO_DB") or "/var/lib/cfm/maxmind/GeoLite2-City.mmdb"

local function geo_country(ip_str)
  if not mmdb_ok or _geo_db_err then return "" end
  if not _geo_db then
    -- .new() takes the path directly — no separate :open() call
    local db, err = mmdb.new(GEO_DB_PATH)
    if not db then
      ngx.log(ngx.WARN, "[cfm] geo_country: mmdb open failed: ", tostring(err), " path=", GEO_DB_PATH)
      _geo_db_err = true
      return ""
    end
    _geo_db = db
  end
  local res, err = _geo_db:lookup(ip_str)
  if not res then return "" end
  return (res.country and res.country.iso_code) or ""
end

-- ─────────────────────────────────────────────────────────────────────────────
-- MAIN ENFORCEMENT
-- ─────────────────────────────────────────────────────────────────────────────

local ip      = real_ip()
local peer_ip = ngx.var.realip_remote_addr or ""
local cf_ip   = ngx.var.http_cf_connecting_ip or ""
local host    = ngx.var.host   or "-"
local uri     = ngx.var.uri    or "-"
local method  = ngx.req.get_method() or "-"
local scheme  = ngx.var.scheme or "http"

local function origin_pass_for(s_in)
  local dst = ngx.var.server_addr or "127.0.0.1"
  return (s_in == "https" and "https://" or "http://") .. dst ..
         (s_in == "https" and ":443" or ":80")
end

-- ── Step 0: Static IP/CIDR bypass ───────────────────────────────────────────
do
  if ngx.var.cfm_bypass_ip == "1" then
    ngx.var.cfm_upstream = "cfm_apache"; ngx.var.cfm_pass = origin_pass_for(scheme)
    return
  end
end

-- ── Step 0: cPanel / webmail hard bypass ─────────────────────────────────────
do
  local h = lower(host); local u = lower(uri)
  local pfx = h:match("^([^%.]+)%.")
  if (pfx == "cpanel" or pfx == "webmail" or pfx == "whm" or pfx == "mail")
     or (u:sub(1, 7) == "/cpanel") or (u:sub(1, 8) == "/webmail") or (u:sub(1, 4) == "/whm") then
    ngx.var.cfm_upstream = "cfm_apache"; ngx.var.cfm_pass = origin_pass_for(scheme)
    return
  end
end

-- ── Step 0a: Local-origin hard bypass ────────────────────────────────────────
do
  local p = peer_ip; local has_cf = cf_ip ~= ""; local srv = ngx.var.server_addr or ""
  if not has_cf and p ~= "" then
    if p:sub(1, 1) == "[" then p = p:sub(2, -2) end
    local b2 = tonumber(p:match("^172%.(%d+)%."))
    if (p == "127.0.0.1") or (p == "::1") or (p == srv)
       or (p:sub(1, 8) == "192.168.") or (p:sub(1, 3) == "10.")
       or (b2 and b2 >= 16 and b2 <= 31) then
      ngx.var.cfm_upstream = "cfm_apache"; ngx.var.cfm_pass = origin_pass_for(scheme)
      return
    end
  end
  if has_cf and srv ~= "" and ip == srv then
    ngx.var.cfm_upstream = "cfm_apache"; ngx.var.cfm_pass = origin_pass_for(scheme)
    return
  end
end


-- ─────────────────────────────────────────────────────────────────────────────
-- [R2] pcall wrapper: Steps 1–4 wrapped so any error defaults to Apache.
-- ─────────────────────────────────────────────────────────────────────────────
local function cfm_enforce()

-- ── POST resume ──────────────────────────────────────────────────────────────
try_apply_post_resume(ip, host)
method = ngx.req.get_method() or method
uri    = ngx.var.uri          or uri

-- ── Step 1: Solved Cookie fast-path ──────────────────────────────────────────
local cfm_ok_cookie = ngx.var.cookie_cfm_ok
if cfm_ok_cookie and cfm_ok_cookie ~= "" and not ngx.ctx.cfm_resumed_post then
  refresh_ok_cookie(cfm_ok_cookie); touch_ok(ip)
  ngx.header["X-CFM-Action"] = "allow_cookie"
  ngx.var.cfm_upstream = "cfm_apache"; ngx.var.cfm_pass = origin_pass_for(scheme)
  return
end

-- ── Step 2: Inline WAF ───────────────────────────────────────────────────────
local waf_ok, waf = pcall(require, "cfm_waf")
if waf_ok and waf and waf.enabled and waf.enabled() then
  if waf_is_excluded(host, uri) then
    if CFG.debug_headers then ngx.header["X-CFM-WAF-Excluded"] = "1" end
  else
    local req_headers = ngx.req.get_headers()
    local req_body    = get_req_body_for_waf(uri, method, CFG.waf_body_max_len)
    local hit, reason, ttl, waf_action = waf.check({
      uri = uri, args = ngx.var.args or "", method = method,
      host = host, ip = ip, cookie = ngx.var.http_cookie or "",
      peer = peer_ip, cf_ip = cf_ip, shdict = SH,
      headers = req_headers, body = req_body,
    })
    if clamav_ok then clamav.notify(ip, hit and reason or nil) end
    if hit then
      waf_action = waf_action or "challenge"
      local p_host = ngx.var.host or host
      local p_uri  = ngx.var.request_uri or uri
      local p_meth = method

      if waf_action == "logonly" then
        ngx.header["X-CFM-Action"] = "logonly"
        ngx.var.cfm_upstream = "cfm_apache"; ngx.var.cfm_pass = origin_pass_for(scheme)
      elseif waf_action == "block" then
        ngx.header["X-CFM-Action"] = "block"
        ngx.var.cfm_upstream = "cfm_block"; ngx.var.cfm_pass = ""
        observe_waf(ip, host, p_uri, p_meth, 403, reason)
      else -- challenge
        if ngx.ctx.cfm_resumed_post then
          ngx.header["X-CFM-Action"] = "block_replayed"
          ngx.var.cfm_upstream = "cfm_block"; ngx.var.cfm_pass = ""
          observe_waf(ip, host, p_uri, p_meth, 403, "REPLAYED_POST_RECHALLENGED")
          return ngx.exit(CFG.block_code)
        end
        local rtok, rerr = store_post_resume(ip, host, ngx.var.request_uri or uri, method)
        if rtok then
          ngx.header["X-CFM-Action"] = "challenge_resume"
          ngx.header["Cache-Control"] = "no-store"
          return ngx.redirect("/?next=" .. esc(with_query_arg((ngx.var.request_uri or uri), "cfm_rt", rtok)), ngx.HTTP_SEE_OTHER)
        end
        ngx.header["X-CFM-Action"] = "challenge"
        ngx.var.cfm_upstream = "cfm_challenge"; ngx.var.cfm_pass = "http://cfm_challenge"
      end

      if waf.should_push and waf.should_push(SH, ip, reason) then
        http_post_unix("/nginx/ip", cjson.encode({
          ip = ip, action = waf_action, ttl_sec = ttl or 600,
          reason = reason, host = p_host, uri = p_uri, method = p_meth,
        }))
      end
      log_route(ngx.INFO, "waf_" .. waf_action .. " ip=" .. ip .. " host=" .. host .. " reason=" .. tostring(reason))
      if waf_action == "block" then return ngx.exit(CFG.block_code) end
      return
    end
  end
end
if not waf_ok and clamav_ok then clamav.notify(ip, nil) end

-- ── Step 3: Bridge Decision ──────────────────────────────────────────────────
-- [R1] ua + country passed so Go can evaluate traffic rules.
local ua_raw  = ngx.var.http_user_agent or ""
local country = geo_country(ip)
local d       = get_decision(ip, host, uri, method, scheme, ua_raw, country)

local ip_action        = d.ip_action        or "allow"
local vh_action        = d.vhost_action      or "allow"
local rule_action      = d.rule_action       or nil
local rule_id          = d.rule_id           or ""
local throttle_profile = d.throttle_profile  or ""
local cache_flag       = d._cache and " cache=1" or ""

if CFG.debug_headers then
  ngx.header["X-CFM-IP"] = ip; ngx.header["X-CFM-Host"] = host
  ngx.header["X-CFM-Dec-IP"] = ip_action; ngx.header["X-CFM-Dec-VH"] = vh_action
  if rule_action then ngx.header["X-CFM-Dec-Rule"] = rule_action end
  if rule_id ~= "" then ngx.header["X-CFM-Rule-ID"] = rule_id end
  if throttle_profile ~= "" then ngx.header["X-CFM-Throttle"] = throttle_profile end
  if d.err then ngx.header["X-CFM-Err"] = tostring(d.err) end
  if d._cache then ngx.header["X-CFM-Cache"] = "1" end
end

-- Block
if ip_action == "block" or vh_action == "block" or rule_action == "block" then
  ngx.header["X-CFM-Action"] = "block"
  ngx.var.cfm_upstream = "cfm_block"; ngx.var.cfm_pass = ""
  log_route(ngx.WARN, "block ip=" .. ip .. " host=" .. host .. cache_flag ..
    (rule_id ~= "" and (" rule_id=" .. rule_id) or ""))
  return ngx.exit(CFG.block_code)
end

-- Challenge
if ip_action == "challenge" or vh_action == "challenge" or rule_action == "challenge" then
  if ngx.ctx.cfm_resumed_post then
    ngx.header["X-CFM-Action"] = "block_replayed"
    ngx.var.cfm_upstream = "cfm_block"; ngx.var.cfm_pass = ""
    return ngx.exit(CFG.block_code)
  end
  local rtok, rerr = store_post_resume(ip, host, ngx.var.request_uri or uri, method)
  if rtok then
    ngx.header["X-CFM-Action"] = "challenge_resume"; ngx.header["Cache-Control"] = "no-store"
    return ngx.redirect("/?next=" .. esc(with_query_arg((ngx.var.request_uri or uri), "cfm_rt", rtok)), ngx.HTTP_SEE_OTHER)
  end
  ngx.header["X-CFM-Action"] = "challenge"
  ngx.var.cfm_upstream = "cfm_challenge"; ngx.var.cfm_pass = "http://cfm_challenge"
  log_route(ngx.INFO, "challenge ip=" .. ip .. " host=" .. host .. cache_flag)
  return
end

-- [R1] Throttle
if rule_action == "throttle" then
  if rules_ok and rules and rules.apply then
    local r = rules.apply({ rule_action = rule_action, throttle_profile = throttle_profile },
      { ip = ip, host = host, uri = uri, method = method, profile = throttle_profile })
    if r and r.action == "throttle" then
      ngx.header["X-CFM-Action"] = "throttle"
      if r.retry_after and tonumber(r.retry_after) then
        ngx.header["Retry-After"] = tostring(math.max(1, math.floor(tonumber(r.retry_after))))
      end
      log_route(ngx.WARN, "throttle ip=" .. ip .. " host=" .. host ..
        (rule_id ~= "" and (" rule_id=" .. rule_id) or ""))
      return ngx.exit(429)
    end
  else
    ngx.header["X-CFM-Action"] = "throttle"; ngx.header["Retry-After"] = "5"
    return ngx.exit(429)
  end
end

-- ── Step 4: Allow ────────────────────────────────────────────────────────────
ngx.header["X-CFM-Action"] = "allow"
ngx.var.cfm_upstream = "cfm_apache"; ngx.var.cfm_pass = origin_pass_for(scheme)
if CFG.log_allows or CFG.debug then
  log_route(ngx.INFO, "allow ip=" .. ip .. " host=" .. host .. " pass=" .. ngx.var.cfm_pass .. cache_flag)
end

end -- cfm_enforce()

-- [R2] pcall: any Lua panic → serve via Apache.
local enforce_ok, enforce_err = pcall(cfm_enforce)
if not enforce_ok then
  ngx.log(ngx.ERR, "[cfm] cfm_enforce_panic err=", tostring(enforce_err),
    " ip=", ip, " host=", host, " uri=", uri, " policy=fail_open_passthrough")
  ngx.var.cfm_upstream = "cfm_apache"
  ngx.var.cfm_pass     = origin_pass_for(scheme)
end
